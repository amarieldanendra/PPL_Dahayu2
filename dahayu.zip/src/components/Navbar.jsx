// Komponen Navbar untuk layout pada website
import Image from "next/image"
import { useEffect, useState } from "react"
export default function Navbar(){
    const [href, setHref] = useState("")
    const [menu, setMenu] = useState(false)
    useEffect(() => {
        if (typeof window !== "undefined") {
            setHref(window.location.href)
        }
    },[])
    return(
        <nav
            className="w-full h-[82px] bg-[#8A9A5B] px-[75px] flex items-center justify-between"
        >
            <a href="/"><h1 className="font-hurricane text-[55px]">Dahayu</h1></a>
            <div className="flex items-center">
                <a className="font-dosis text-[22px]" href="/">Home</a>
                <a className="font-dosis text-[22px] ml-7" href="/#categories">Categories</a>
                <a className="font-dosis text-[22px] ml-7" href="/#bestProducts">Explore</a>
                {/* Mengecek apakah berada di page login/register */}
                {(!href.includes("login") && !href.includes("register")) &&  <Image onClick={() => setMenu(!menu)} className="ml-7 cursor-pointer" width={55} height={55} src="/profPic.png" />}
                {href.includes("register") &&<a className="font-dosis text-[22px] ml-7" href="#">Login</a>}
                {href.includes("login   ") &&<a className="font-dosis text-[22px] ml-7" href="#">Register</a>}
            </div>
            {   menu &&
                <div
                    className="fixed w-fit font-dosis text-[#023020] text-xl right-20 top-20"
                >
                    <a className="px-4 py-2 text-inherit border-b-2 border-[#023020] bg-[#F4EBD0] w-[200px] block" href="/profile">
                        Profile
                    </a>
                    <a className="px-4 py-2 text-inherit border-b-2 border-[#023020] bg-[#F4EBD0] w-[200px] block" href="">
                        Create Post
                    </a>
                    <a className="px-4 py-2 text-inherit bg-[#F4EBD0] w-[200px] block" href="">
                        Logout
                    </a>
                </div>
            }
        </nav>
    )
}